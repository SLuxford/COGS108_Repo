# Assignments
Assignments for the current iteration of COGS 108 - Wi19. 

Assigments are typically released by Monday mornings and due on Sunday nights, either one or two weeks later, as specified below:

#### A1: Setting-Up
- Released: Monday, January 14th (W2)
- Due: Sunday, January 20th (W2)

## Project Schedule

Intermixed with this schedule is your final project.

#### Project Proposal
Due Monday, February 18th @ 11:59 pm (W6)

#### Final Project
Due Thursday, March 21st @ 11:59 pm (Finals Week)
